drop database bdConsulta;

Create database bdConsulta;
use bdConsulta;

-- Tabela de Pacientes
CREATE TABLE Pacientes(
    idP INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(20) NOT NULL,
    genero VARCHAR(1) NOT NULL,
    telefone VARCHAR(16),
    email VARCHAR(50),
    cidade VARCHAR(25),
    bairro VARCHAR(25)
);

select * from Medicos;

-- Tabela de Médicos
CREATE TABLE Medicos(
    idM INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(20) NOT NULL,
    especialidade VARCHAR(50),
    genero VARCHAR(1) NOT NULL,
    telefone VARCHAR(15),
    email VARCHAR(50),
    cidade VARCHAR(25),
    bairro VARCHAR(25)
);

drop table Agenda_medico;
select * from Agenda_medico;
-- Tabela de Agenda dos Médicos

CREATE TABLE Agenda_medico(
	idA INT AUTO_INCREMENT PRIMARY KEY,
	idM INT NOT NULL,
	data_agenda DATE NOT NULL,
	horario VARCHAR(15),
    FOREIGN KEY (idM) REFERENCES Medicos(idM)
);


-- Tabela de Consultas
CREATE TABLE Consultas(
    idC INT AUTO_INCREMENT PRIMARY KEY,
    idP INT NOT NULL,
    idA INT NOT NULL,
    FOREIGN KEY (idP) REFERENCES Pacientes(idP),
    FOREIGN KEY (idA) REFERENCES Agenda_medico(idA)
);

-- Tabela de Notificações
CREATE TABLE Lembretes(
    id INT AUTO_INCREMENT PRIMARY KEY,
    idC INT NOT NULL,
    mensagem VARCHAR(255) NOT NULL,
    data_hora DATETIME NOT NULL,
    FOREIGN KEY (idC) REFERENCES Consultas(idC) ON DELETE CASCADE
);

select * from Lembretes;
-- Tabela de Notificações
CREATE TABLE Usuarios(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(20) NOT NULL,
    senha VARCHAR(16)
);


INSERT INTO Usuarios(id, nome, senha) VALUES
(1, 'Adriano Paciencia', '123456'),
(2, 'Simão Pedro', '123456'),
(3, 'Eugenia Augusta', '123456'),
(4, 'Manuel Cazongo', '123456');


 select Medicos.nome, 
 Medicos.especialidade, 
 Agenda_medico.data_agenda, 
 Agenda_medico.horario 
 from Medicos LEFT JOIN Agenda_medico 
 ON Medicos.idM = Agenda_medico.idM;
 
 drop table Lembretes;