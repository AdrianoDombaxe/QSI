<?php
function pdo_connect_mysql() {
    $servidor = 'localhost';
    $usuario = 'root';
    $senha = '';
    $base_dados = 'bdConsulta';
    try {
    	return new PDO('mysql:host=' . $servidor . ';dbname=' . $base_dados . ';charset=utf8', $usuario, $senha);
    } catch (PDOException $exception) {
    	exit('Falha ao conectar-se com a base de dados');
    }
}

function template_header($title) {
echo <<<EOT
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>$title</title>
		<link href="css/style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
    <nav class="navtop">
    	<div>
    		<h1>Agendamento de consultas médicas</h1>
            <a href="home.php">Home</a>
    		<a href="read_medico.php">Médico</a>
			<a href="read_paciente.php">Paciente</a>
			<a href="read_agenda.php">Agenda</a>
			<a href="read_consultas.php">Consulta</a>
    	</div>
    </nav>
EOT;
}
function template_footer() {
echo <<<EOT
    </body>
</html>
EOT;
}
?>