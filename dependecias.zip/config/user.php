<?php

include_once 'conexao.php';
class User {
    private $conn;
    private $table_name = 'Usuarios';

    public $id;
    public $nome;
    public $senha;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function login() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE nome = :nome AND senha = :senha";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':nome', $this->nome);
        $stmt->bindParam(':senha', $this->senha);

        $stmt->execute();

        if($stmt->rowCount() > 0) {
            return true;
        }
        return false;
    }
}
?>